#include "LT_PMBusDeviceLTM2987.h"

uint32_t LT_PMBusDeviceLTM2987::cap_ =  HAS_VOUT
                                        | HAS_VIN
                                        | HAS_TEMP
                                        | HAS_STATUS_WORD
                                        | HAS_STATUS_EXT
                                        ;