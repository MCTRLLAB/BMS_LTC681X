#include "LT_PMBusDeviceLTC2974.h"

uint32_t LT_PMBusDeviceLTC2974::cap_ =  HAS_VOUT
                                        | HAS_VIN
                                        | HAS_IOUT
                                        | HAS_POUT
                                        | HAS_TEMP
                                        | HAS_STATUS_WORD
                                        | HAS_STATUS_EXT
                                        ;