#include "LT_PMBusDeviceLTC2977.h"

uint32_t LT_PMBusDeviceLTC2977::cap_ =  HAS_VOUT
                                        | HAS_VIN
                                        | HAS_TEMP
                                        | HAS_STATUS_WORD
                                        | HAS_STATUS_EXT
                                        ;